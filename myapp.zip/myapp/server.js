var express = require('express');  
var savefile = require("socketio-file-upload");
var app = express().use(savefile.router);  
var server = require('http').createServer(app);  
var io = require('socket.io')(server);
app.use(express.static(__dirname + '/node_modules'));  
app.get('/', function(req, res,next) {  
    res.sendFile(__dirname + '/index.html');
});

io.on('connection', function(client) {
    var uploader = new savefile();
    uploader.dir = "/Users/vip/myapp/node_modules/upload";
    uploader.listen(client);
    var name;
  
    console.log('Client connected...');
    client.on('join', function(usname) {
        console.log("hello "+usname);
       name=usname;    
    });
    client.on('messages', function(data) {
        
         client.emit('broad', data);
         client.broadcast.emit('broad',data);
     });

   uploader.on("saved", function(event){  
 data="<span class='usern'>"+name+"</span>: <a href='/upload/"+event.file.name+"'target='_blank'> download file</a>"
         client.emit('broad', data);
             client.broadcast.emit('broad',data);
     });
});
server.listen(8000);